package model;

public class ProductDTO {
	private String productName;
	private int count;
	
	
	
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getCount() {
		return count;
	}
	public void setCount() {
		count++;
	}
	
	
}
